$(function(){
    // 售卖币种
    $.ajax({
        url:"http://box.bz-bss.com/index.php?controller=public&action=GetCurrencyRate",
        type:"GET",
        dataType:"jsonp",
        jsonp:"callback",
        jsonpCallback:"success_jsonCallback",
        success:function(json){
            if(json!=null){
                if(json.ack=="success"){
                    var html="";
                    for(var k in json.data){
                        html+="<option value="+json.data[k].rate+" data-symbol="+json.data[k].symbol+">"+json.data[k].desc+"</option>";
                    }
                    $("#currency").append(html);
                }
            }
        },
        error:function(){
            console.log("网络错误请检查！");
        }
    })
    // 不同币种change事件
    var currencyRate;
    var currencySymbol;
    $("#currency").change(function(){
        currencyRate=Number($(this).val());
        currencySymbol=$(this).find("option:selected").data("symbol");
        // console.log(currencySymbol);
    })
    var checkSku=$("#checkSKU");
    var skuInput=checkSku.parent().nextAll().children(("input"));
    var purchasePrice;
    var sku;
    var tariff;//进口关税
    var freight;
    var postage;//尾程费用
    var incomeTax;//收入税率
    var platFormTax;// 不同平台的税率(平台佣金折扣)
    var payTax;// 不同支付方式的税率
    var promotion;//推广税率
    // var grossRate;//要求毛利率
    //鼠标点击查询sku
    checkSku.click(function(){
        getSkuMsg();
        $("#freight").val("");
        $("#shipping").empty();
        shipping();
    });
    //按回车键查询sku
    checkSku.prev().keydown(function(e){
        if(e.keyCode==13){
            getSkuMsg();
            $("#freight").val("");
            $("#shipping").empty();
            shipping();
        }
    })
    // 光标离开计算采购价
    $("#purchasePrice").blur(function(){
        purchasePrice=Number($("#purchasePrice").val());//采购价
    })
    // 手动输入长宽高，鼠标离开输入框，自动计算体积重
    for(var i=1;i<4;i++){
        (function(j){
            $(skuInput[j]).blur(function(){
                if($(skuInput[1]).val()!=""&&$(skuInput[2]).val()!=""&&$(skuInput[3]).val()!=""){
                    getVolumeWeight();
                    $("#freight").val("");
                    $("#shipping").empty();
                    shipping();
                }else if($(skuInput[0]).val()!=""){
                    $("#freight").val("");
                    $("#shipping").empty();
                    shipping();
                }else{
                    $(skuInput[4]).val("");
                    $("#freight").val("");
                    $("#shipping").empty();
                    $("#shipping").append("<option value='0'>--请选择--</option>");
                }
            })     
        })(i)
    }
    function getSkuMsg(){
        sku=Number(checkSku.prev().val());//shu号
        //一 : 包装信息
        $.ajax({
            url:"http://box.bz-bss.com/index.php?controller=public&action=GetProductInfoByNumber&product_number="+sku,
            type:"POST",
            dataType:"jsonp",
            jsonp: "callback",
            jsonpCallback:"success_jsonpCallback",
            success:function(json){
                if(json!=null){
                    if(json.ack=="success"){
                        var weight=json.data.weight;
                        var length=json.data.length;
                        var width=json.data.width;
                        var height=json.data.height;
                        var showPurchasePrice=json.data.last_purchase_price;
                        $(skuInput[0]).val(weight);
                        $(skuInput[1]).val(length);
                        $(skuInput[2]).val(width);
                        $(skuInput[3]).val(height);
                        // 体积重
                        getVolumeWeight();
                        $("#purchasePrice").val(showPurchasePrice);
                        purchasePrice=Number($("#purchasePrice").val());//采购价
                        if(/*$("#purchasePrice").val()!=null||*/$(skuInput).val()!=null){
                            for(var i=0;i<4;i++){
                                $(skuInput[i]).attr("disabled","disabled");
                            }
                            // $("#purchasePrice").attr("disabled","disabled");
                        }
                    }else{
                        alert("没有查询到商品");
                        window.location.reload();
                        // $(skuInput).val("");
                        // $("#purchasePrice").val("");
                        // for(var i=0;i<4;i++){
                        //         $(skuInput[i]).removeAttr("disabled");
                        //     }
                        // // $("#purchasePrice").removeAttr("disabled");
                    }
                }   
            },
            error:function(msg){
                console.log("网络故障请检查");
            }
        })
    }
    function getVolumeWeight(){
        //体积重：单个包装的 长*宽*高 （这个需要物流设置，不同的物流渠道，体积重的计算方式不一样，用 单个包装的 长*宽*高 除以 5000-7000不等）
        var num=6;
        var cLength=Number($(skuInput[1]).val());
        var cWidth=Number($(skuInput[2]).val());
        var cHeight=Number($(skuInput[3]).val());
        var volumeWeight=(cLength*cWidth*cHeight)/num;
        $(skuInput[4]).val(volumeWeight);
    }
//二 ：销售国家，平台和物流渠道选择
// id、国家、进口税、二宇码、销售税
    var country =[
        [1,"英国","16.5","GB","7.5%"],
        [2,"德国","19","DE","19%"],
        [3,"澳大利亚","10","AU","10%"],
        [4,"美国","0","US","0%"]
    ];
    var html="";
    for(var i=0;i<country.length;i++){
        html+="<option value="+country[i][0]+">"+country[i][1]+"</option>";
    }
    $("#country").append(html);
   // TODO:
    // 国家change事件
    $("#country").change(function(){
        var tar=Number($(this).val())-1;
        $("#tariff").val(country[tar][2]);
        tariff=Number($("#tariff").val());//进口关税
        incomeTax=Number(country[tar][4].substring(0,country[tar][4].length-1));//收入税率
         //仓库
        $.ajax({
            url:"http://box.bz-bss.com/index.php?controller=public&action=GetWarehouseAndShippingList",
            type:"GET",
            dataType:"jsonp",
            jsonp: "callback",
            jsonpCallback:"success_jsonpCallback",
            success:function(json){
                var data=json.data;
                if(json!=null){
                    var html="";
                    for(var k in data){
                        html+="<option value="+data[k].name+">"+data[k].name+"</option>";
                    }
                    $("#storehouse").append(html);
                    // 仓库change事件
                    $("#storehouse").change(function(){
                        var tarName=$(this).val();
                        for(var k in data){
                            if(data[k].name==tarName){
                                $("#logistics").html("");
                                var storehouse=data[k].children;
                                var html="<option>--请选择--</option>";
                                for(var n in storehouse){
                                    html+="<option value="+n+">"+storehouse[n].name+"</option>";
                                }
                                $("#logistics").append(html);    
                            }
                        }
                    })
                    // TODO:countryCode？
                    // 尾程运费计算
                    $("#logistics").change(function(){
                        var logisticsId=$(this).val();
                        var countryCode=country[tar][3];
                        // console.log(countryCode)
                        //毛重
                        var grossWeight=Number($(skuInput[0]).val())/1000;
                        // 体积重
                        var volumeWeight=Number($(skuInput[4]).val())/1000;
                        var weight=grossWeight>volumeWeight?grossWeight:volumeWeight;
                        $.ajax({
                            url:"http://box.bz-bss.com/index.php?controller=public&action=Calculate&shipping_method_id="+logisticsId+"&country_code="+countryCode+"&weight="+weight,
                            type:"POST",
                            dataType:"jsonp",
                            jsonp:"callback",
                            jsonpCallback:"success_jsonpCallback",
                            success:function(json){
                                $("#postage").val(json.postage);
                                postage=Number($("#postage").val());//尾程费用
                            },
                            error:function(){console.log("网络故障请检查");}
                        })
                    })
                }
            },
            error:function(){
                console.log("网络故障请检查");
            }
        })
    })

    // 平台
    var platform =[
        [1,"amazon",["普通类","通用类"],["收款平台服务费:1%"],"16.5%"],
        [2,"ebay",["类别一","类别二"],["palpay大额:6%","palpay小额:3.2%"],"19.0%"]
    ];
    var htm="";
    for(var i=0;i<platform.length;i++){
        htm+="<option value="+platform[i][0]+">"+platform[i][1]+"</option>";
    }
    $("#platform").append(htm);
    // 平台change事件
    $("#platform").change(function(){
        $("#category").html("");
        $("#pay").html("");
        var tarNum=Number(($(this).val()))-1;
        var html="";
        for(var i=0;i<platform[tarNum][2].length;i++){
            html+="<option value="+tarNum+">"+platform[tarNum][2][i]+"</option>";
        }
        $("#category").append(html);    
        if(tarNum==0){
            $("#pay").html("<option value="+tarNum+">"+platform[tarNum][3][0]+"</option>");
        }else{
            var msg="";
            for(var i=0;i<platform[tarNum][3].length;i++){
                msg+="<option value="+tarNum+">"+platform[tarNum][3][i]+"</option>";
            }    
            $("#pay").append(msg);    
        }
        $("#pay").change(function(){
            payTax=$("#pay").children(":selected").html();// 不同支付方式的税率
            payTax=Number(payTax.substring(payTax.lastIndexOf(':')+1,payTax.lastIndexOf('%')));
        })
        $("#discount").val(platform[tarNum][4]);
        var discount=$("#discount").val();
        platFormTax=Number(discount.substring(0,discount.length-1));
        payTax=$("#pay").children(":selected").html();// 不同支付方式的税率
        payTax=Number(payTax.substring(payTax.lastIndexOf(':')+1,payTax.lastIndexOf('%')));
    })
    //头程运费方式
    function shipping(){
        var shipping=[[1,"海运"],[2,"空运"],[3,"快递"]];
        var html="<option value='0'>--请选择--</option>";
        for(var i=0;i<shipping.length;i++){
            html+="<option value="+shipping[i][0]+">"+shipping[i][1]+"</option>";
        }
        $("#shipping").append(html);
    }
    // shipping() 计算运费;
    $("#shipping").change(function(){
        var tar=$(this).val();
        //毛重
        var grossWeight=Number($(skuInput[0]).val())/1000;
        // 体积重
        var volumeWeight=Number($(skuInput[4]).val())/1000;
        var weight=grossWeight>volumeWeight?grossWeight:volumeWeight;
        if(tar=="1"){
            var cLength=Number($(skuInput[1]).val());
            var cWidth=Number($(skuInput[2]).val());
            var cHeight=Number($(skuInput[3]).val());
            freight=(cLength*cWidth*cHeight)/1000000*1500;
            $("#freight").val(freight);
        }else if(tar=="2"){
            freight=weight*32;
            $("#freight").val(freight);
        }else{
            freight=weight*40;
            $("#freight").val(freight);
        }
    })
    $("#promotion").blur(function(){
        promotion=Number($("#promotion").val());
        console.log(promotion)
    })
    // 预算要求毛利率/售价
    var price;
    var tbody=$(".floor5 table tbody");
    var num;
    var nextDom=$("#budget").nextAll();
    var $input=$(nextDom[0]);
    var $btn=$(nextDom[1]);
    $("#budget").change(function(){
        var tar=$(this).val();
        num=tar;
        if(tar=="1"){
            $input.attr("placeholder","请输入要求利润率");
            $btn.html("计算售价");
        }else if((tar=="2")){
            $input.attr("placeholder","请输入售价");
            $btn.html("计算利润率");
        }
    })
// 一开始加载页面时渲染数据（预算）
    var storage=window.localStorage;
    var msg=storage.valueOf();
    var calNum=-1;
    if(msg!=null){
        $("#noMsg").hide();
        // console.log(msg)
        var html="";
        for(var k in msg){
            // console.log(JSON.parse(msg[k]).calNum)
            calNum+=1;
            // console.log(calNum)
            var data=JSON.parse(msg[k]);
            html+=`<tr>
                <td><span class="cancel" data-id="${data.calNum}">X</span><a href="javascript:" data-index="${data.calNum}">${data.sku}</a></td>
                <td>${data.purchasePrice}</td>
                <td>${data.tariff}</td>
                <td>${data.freight}</td>
                <td>${data.postage}</td>
                <td>${data.incomeFee}</td>
                <td>${data.platformFee}</td>
                <td>${data.payFee}</td>
                <td>${data.promotionFee}</td>
                <td>${data.rate}</td>
                <td>${data.price}</td>
            </tr>`;    
        }
        tbody.append(html);    
    }
    $btn.click(function(){
        calNum+=1;
        // console.log("计算",calNum)
        var inputVal=Number($input.val());
        // console.log(currencyRate);
        if(purchasePrice!=""&&freight!=""&&postage!=null&&tariff!=null&&incomeTax!=""&&platFormTax!=""&&payTax!=""&&promotion!=null&&inputVal!=""){
            if(num=="1"){
                price=(purchasePrice+freight+postage+tariff)/(1-(incomeTax+platFormTax+payTax+promotion+inputVal)/100);
                cost(price,calNum);
            }else{
                price=inputVal;
                cost(price,calNum);
            }
        }else{
            alert("请把信息填完整")
        }
    })

    
    // 调用函数计算预算
    function cost(price,calNum){
    //sku号,purchasePrice采购价,tariff进口关税,freight头程费用,postage尾程费用,
    //incomeTax收入税率,platFormTax不同平台的税率(平台佣金折扣),payTax不同支付方式的税率,promotion 推广税率,grossRate 要求毛利率, 
    //price售价：传参得到;
    // currencyRate售卖币率
        // currencySymbol=$("currency").children(":selected").attr("symbol");
        // console.log(currencySymbol)
        //收入税
        var incomeFee=price*incomeTax/100;
        //平台费用=售价*不同平台的税率
        var platformFee=price*platFormTax/100;
        //支付费用=售价*不同支付方式的税率
        var payFee=price*payTax/100;
        //推广费用=售价*推广税率
        var promotionFee=price*promotion/100;
        //总成本=采购价+头程费+尾程费+进口税+收入税+平台税+支付税+推广税
        var totalCost=purchasePrice+freight+postage+tariff+incomeFee+platformFee+payFee+promotionFee;
        //毛利率=（售价-总成本）/售价
        var rate=(price-totalCost)/price*100;
        // $("#price").val(price.toFixed(2));
        // console.log(price,purchasePrice,freight,postage,tariff,incomeFee,platformFee,payFee,promotion,promotionFee,rate,totalCost)
        $("#noMsg").hide();
        var html="";
            html+=`<tr>
                <td><span class="cancel" data-id="${calNum}">X</span><a href="javascript:" data-index="${calNum}">${sku}</a></td>
                <td>${purchasePrice.toFixed(2)}</td>
                <td>${tariff.toFixed(2)}</td>
                <td>${freight.toFixed(2)}</td>
                <td>${postage.toFixed(2)}</td>
                <td>${incomeFee.toFixed(2)}</td>
                <td>${platformFee.toFixed(2)}</td>
                <td>${payFee.toFixed(2)}</td>
                <td>${promotionFee.toFixed(2)}</td>
                <td>${rate.toFixed(2)}</td>
                <td>${currencySymbol+(price/currencyRate).toFixed(2)}</td>
            </tr>`;
        tbody.append(html);
    // 显示、存储数据
        var weight=$(skuInput[0]).val();//毛重
        var length=$(skuInput[1]).val();//包装尺寸：长
        var width=$(skuInput[2]).val();//包装尺寸：宽
        var height=$(skuInput[3]).val();//包装尺寸：高
        var volumeWeight=$(skuInput[4]).val();//体积重
        var country=$("#country").children(":selected").html();//国家
        var platform=$("#platform").children(":selected").html();//平台
        var category=$("#category").children(":selected").html();//商品类别
        var pay=$("#pay").children(":selected").html();//支付方法
        var discount=$("#discount").val();//平台佣金折扣（%）
        var storehouse=$("#storehouse").children(":selected").html();//仓库
        var logistics=$("#logistics").children(":selected").html();//物流方法
        var shipping=$("#shipping").children(":selected").html();//头程运费方式
        // promotion//推广费用(率)
        var currency=$("#currency").children(":selected").html();//售卖币种
        if(!window.localStorage){
            alert("浏览器不支持localstorage");
            return false;
        }else{
            var data;
            data={
                calNum:calNum,
                sku:sku,
                purchasePrice:(purchasePrice.toFixed(2)),
                tariff:(tariff.toFixed(2)),
                freight:(freight.toFixed(2)),
                postage:(postage.toFixed(2)),
                incomeFee:(incomeFee.toFixed(2)),
                platformFee:(platformFee.toFixed(2)),
                payFee:(payFee.toFixed(2)),
                promotionFee:(promotionFee.toFixed(2)),
                rate:(rate.toFixed(2)),
                price:(currencySymbol+(price/currencyRate).toFixed(2)),
                weight:weight,
                length:length,
                width:width,
                height:height,
                volumeWeight:volumeWeight,
                country:country,
                platform:platform,
                category:category,
                pay:pay,
                discount:discount,
                storehouse:storehouse,
                logistics:logistics,
                shipping:shipping,
                promotion:promotion,
                currency:currency
            };
            var d=JSON.stringify(data);
            storage.setItem(calNum,d);
        }
    }
    tbody.click(function(e){
        if(e.target.nodeName=="A"){
            $(".floor6").show();
            var index=$(e.target).data("index");
            var getMsg=JSON.parse(storage.getItem(index));
            var html="";
            html+=`
            <table>
                <thead>
                    <tr>
                        <th>SKU:</th>
                        <th>${getMsg.sku}</th>
                    </tr>    
                </thead>
                <tbody>
                    <tr>
                        <td>毛重(g)：</td>
                        <td>${getMsg.weight}</td>
                    </tr>
                    <tr>
                        <td>包装尺寸：</td>
                        <td>
                            <div>
                                <span>长(cm) :</span>
                                <span>宽(cm) :</span>
                                <span>高(cm) :</span>
                            </div>
                            <div>
                                <span>${getMsg.length}</span>
                                <span>${getMsg.width}</span>
                                <span>${getMsg.height}</span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>SKU体积重(g)：</td>
                        <td>${getMsg.volumeWeight}</td>
                    </tr>
                    <tr>
                        <td>国家：</td>
                        <td>${getMsg.country}</td>
                    </tr>
                    <tr>
                        <td>平台：</td>
                        <td>${getMsg.platform}</td>
                    </tr>
                    <tr>
                        <td>商品类别：</td>
                        <td>${getMsg.category}</td>
                    </tr>
                    <tr>
                        <td>支付方法：</td>
                        <td>${getMsg.pay}</td>
                    </tr>
                    <tr>
                        <td>平台佣金折扣（%）：</td>
                        <td>${getMsg.discount}</td>
                    </tr>
                    <tr>
                        <td>仓库：</td>
                        <td>${getMsg.storehouse}</td>
                    </tr>
                    <tr>
                        <td>物流方法：</td>
                        <td>${getMsg.logistics}</td>
                    </tr>
                    <tr>
                        <td>头程运费方式：</td>
                        <td>${getMsg.shipping}</td>
                    </tr>
                    <tr>
                        <td>推广费用率（%）：</td>
                        <td>${getMsg.promotion}</td>
                    </tr>
                    <tr>
                        <td>售卖币种：</td>
                        <td>${getMsg.currency}</td>
                    </tr>
                </tbody>

            </table>
            `;
            $(".floor6 .detail").html(html);
        }
        if(e.target.nodeName=="SPAN"){
            // console.log($(e.target).data("id"));
            var id=$(e.target).data("id");
            if(confirm("确定删除该商品吗？")){
                storage.removeItem(id);
                window.location.reload();
            }
        }
    })
    // 删除localStorage所有数据
    // window.localStorage.clear();
    
    $("#cancel").click(function(){
        $(".floor6").hide();
    })
   
})